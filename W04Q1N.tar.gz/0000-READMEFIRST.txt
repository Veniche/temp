Selamat pagi semuanya, pagi ini kita POP Quiz ya! 🤩 

- Batas Waktu Submisi: Today, 08:00:59 AM (GMT+7 / WIB)
- Format Jawaban: ZCZC W04 Q1N Jawaban (N adalah nomor pertanyaan yang dijawab.)
- Jawaban dikirimkan ke <@!810472055031988254> dengan perintah !a atau !answer.
Contoh jawaban(BUKAN JAWABAN SEBENARNYA):
!a ZCZC W04 Q10 Jolan Tru

Catatan penting sebelum menjawab pertanyaan:
- Jawaban dari setiap soal dikirimkan secara terpisah.
- Jawaban boleh dikirim secara acak.
- JAWABAN YANG TIDAK SESUAI DENGAN FORMAT TIDAK AKAN DINILAI (JAWABAN DIABAIKAN)
- ORANG YANG MENJAWAB SOAL YANG SAMA 2 KALI AKAN LANGSUNG DAPAT 4 TELUR MATA SAPI SPESIAL!(0-0-0-0)

========================================================================================
SOAL KUIS

1. [Output] Apa output dari program dibawah ini? Apakah sistemnya Little Endian atau Big Endian?
Format Jawaban: OutputPrint1-OutputPrint2-Sistem
Contoh Jawaban: ZCZC W04 Q11 z-Z-BE (BUKAN JAWABAN SEBENARNYA)
vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
#include <stdio.h>
char  ch_array[]="abcdefg";
char* ch_pointer="ABCDEFG";

void main(void) {
   printf("  ch_array =%c\n",  ch_array[0]);
   ch_pointer = ch_pointer + 5;
   printf(" *ch_pointer =%c\n", *ch_pointer);
}
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2. [Output] Apa output dari program dibawah ini?
Format Jawaban: ZCZC W04 Q12 OutputPrint1-OutputPrint2-OutputPrint3
Contoh Jawaban: ZCZC W04 Q12 1234-5678-9012 (BUKAN JAWABAN SEBENARNYA)
vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
#include <stdio.h>
char chrary[]="ZZZZABCD";
void main(void) {
   char  chrvar = 'M';
   int   intvar = 0x41424344;
   int*  intptr = (int*) chrary;
   printf("%s\n",  chrary);
   printf("%c\n",  chrvar);
   *intptr = intvar;
   printf("%s\n",  chrary);
}
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
3. [Output] Jawab nomor ini dengan output chktoken W04QUIZSELASA (PASTIKAN AKUN GITHUB ANDA DENGAN OUTPUT $USER ANDA SUDAH 100% SAMA PERSIS)
CONTOH: ZCZC W04 Q13 aceyoga 1234-5678

4. [True/False] Di C Programming, apakah sebuah pointer dapat menyimpan alamat pointer lain? Apakah alamat pointer penyimpan alamat pointer 
tersebut dapat disimpan oleh pointer penyimpan alamat pointer penyimpan alamat pointer juga, dan seterusnya?
Format Jawaban: ZCZC W04 Q14 Jawaban
Contoh Jawaban: ZCZC W04 Q14 False (BUKAN JAWABAN SEBENARNYA)


========================================================================================

May the fork() be with you. Jolan Tru!
